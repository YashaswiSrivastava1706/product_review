package com.exitAssignment.server.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.exitAssignment.server.service.CustomUserDetailService;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Configuration
public class MySecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private jwtAuthenticationEntryPoint unauthorizedHandler;
	
	@Autowired
	private CustomUserDetailService userDetailService;
	
	@Autowired
	private AuthenticationFilter jwtAuthenticationFilter;
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// Configure the authentication manager to use the custom user details service
		auth.userDetailsService(this.userDetailService).passwordEncoder(passwordEncoder());
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		// Create a password encoder bean using BCrypt
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.csrf().disable() // Disable CSRF protection
			.cors().disable() // Disable Cross-Origin Resource Sharing (CORS)
			.authorizeRequests() // Configure URL authorization
				.antMatchers("/api/generate-token", "/api/user", "/api/register").permitAll() // Allow these URLs without authentication
				.antMatchers(HttpMethod.OPTIONS).permitAll() // Allow HTTP OPTIONS requests without authentication
				.anyRequest().authenticated() // Require authentication for any other requests
			.and()
				.exceptionHandling().authenticationEntryPoint(unauthorizedHandler) // Handle unauthorized requests
			.and()
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS); // Configure session management to be stateless (no sessions)
		
		http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class); // Add the JWT authentication filter before the UsernamePasswordAuthenticationFilter
	}
	
	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		// Expose the AuthenticationManager bean
		return super.authenticationManagerBean();
	}
}
