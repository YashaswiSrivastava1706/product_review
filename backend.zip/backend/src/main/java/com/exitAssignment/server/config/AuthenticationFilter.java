package com.exitAssignment.server.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.exitAssignment.server.service.CustomUserDetailService;

@Component
public class AuthenticationFilter extends OncePerRequestFilter{

	
	@Autowired
	private CustomUserDetailService customUserDetailsService;
	@Autowired
	private jwtUtils jwtUtils;
	
    // This method is called for each incoming request
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
        // Retrieve the JWT token from the request header
		final String requestTokenHeader =request.getHeader("Authorization");
		String username=null;
		String jwtToken=null;

		if(requestTokenHeader!=null && requestTokenHeader.startsWith("Bearer "))
		{
            // Extract the token from the header
			jwtToken=requestTokenHeader.substring(7);

			try {
                // Extract the username from the JWT token
				username=jwtUtils.extractUsername(jwtToken);

			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

	    // Security
        // Load user details from the custom user details service based on the extracted username
	
		UserDetails userDetials   =this.customUserDetailsService.loadUserByUsername(username);
		
        // If the username is not null and there is no existing authentication in the SecurityContextHolder
		if(username!=null && SecurityContextHolder.getContext().getAuthentication()==null)
		{
            // Create a new authentication token using the user details and set it in the SecurityContextHolder
			UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=new UsernamePasswordAuthenticationToken(userDetials,null,userDetials.getAuthorities());
			
            // Set additional details for the authentication token
			usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
		
		
		
		}
		else
		{
			System.out.println("Token is not validated...");
		}
		}
		
        // Continue the filter chain for the request
		filterChain.doFilter(request,response);
	}
}
