package com.exitAssignment.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.exitAssignment.server.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {
	
	// This interface extends JpaRepository, which provides the basic CRUD operations for the User entity.

	// Custom methods for querying user data can be defined in this interface.
	
	public User findByUsernameAndPassword(String username, String password);
	// This method is used to find a user by their username and password.
	// It accepts two parameters: username and password.
	// The method name follows the naming convention of Spring Data JPA, allowing it to generate the appropriate query based on the method name.
	// By defining this method, Spring Data JPA automatically generates the query to find a user by their username and password from the UserRepository.
	
	public User findByUsername(String userName);
	// This method is used to find a user by their username.
	// It accepts a single parameter: the username.
	// The method name follows the naming convention of Spring Data JPA, allowing it to generate the appropriate query based on the method name.
	// By defining this method, Spring Data JPA automatically generates the query to find a user by their username from the UserRepository.
	
	// The UserDao interface acts as a repository for managing User entities in the database. It allows performing CRUD operations (create, read, update, delete) on User objects.
	// JpaRepository is a generic interface that takes two parameters: the entity type (User) and the primary key type (Integer).
	// By extending JpaRepository<User, Integer>, the UserDao interface inherits the methods for CRUD operations from JpaRepository, such as save(), findById(), findAll(), delete(), etc.
	// In addition, custom methods can be defined to perform specific queries on User data using Spring Data JPA's query generation mechanism.
}
