package com.exitAssignment.server.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exitAssignment.server.dao.ProductDao;
import com.exitAssignment.server.model.Product;

/***
 * @author Yashaswi Srivastava
 */

@Service
public class ProductService {
	
	@Autowired
	private ProductDao productDao;

	public List<Product> getProduct() {
		// This method retrieves all the products from the database.
		// It uses the findAll() method of the ProductDao to get all the products.
		// The products are returned as a List<Product>.

		return this.productDao.findAll();
	}
	
	public Product addProduct(Product product) {
		// This method adds a new product to the database.
		// It takes the product object as a parameter.
		// First, it checks if a product with the same productId already exists using the findByProductId() method of the ProductDao.
		// If a product with the same productId exists, it returns null to indicate that the product cannot be added.
		// Otherwise, it saves the product using the save() method of the ProductDao and returns the saved product.

		Product productId = this.productDao.findByProductId(product.getProductId());
		System.out.println(productId);
		if (productId != null) {
			return null;
		}
		return this.productDao.save(product);
	}
	
	public List<Product> getProductByName(String productName) {
		// This method retrieves products from the database based on their name.
		// It takes the productName as a parameter.
		// It uses the findByProductName() method of the ProductDao to get the products matching the given name.
		// The products are returned as a List<Product>.

		List<Product> product = this.productDao.findByProductName(productName);
		return product;
	}

	public Product getProductById(int id) {
		// This method retrieves a product from the database based on its ID.
		// It takes the ID as a parameter.
		// It uses the findByProductId() method of the ProductDao to get the product with the given ID.
		// If no product is found with the given ID, it catches the NoSuchElementException and prints a message.
		// The retrieved product is returned.

		Product product = null;
		try {
			product = productDao.findByProductId(id);
		} catch (NoSuchElementException e) {
			System.out.println("No product with this id");
		}
		//System.out.println(product);

		return product;
	}
	
	public Long getNumberofProducts() {
		// This method returns the total number of products in the database.
		// It uses the count() method of the ProductDao to get the count.
		// The count is returned as a Long value.
		
		return this.productDao.count();
	}
}
