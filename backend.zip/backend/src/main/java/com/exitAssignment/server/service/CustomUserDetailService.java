package com.exitAssignment.server.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.exitAssignment.server.dao.UserDao;
import com.exitAssignment.server.model.User;

/***
 * @author Yashaswi Srivastava
 */

@Service
public class CustomUserDetailService implements UserDetailsService {
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// This method is called by Spring Security to load a user based on their username.
		// It takes the username as a parameter and returns a UserDetails object that represents the user.
		// If no user is found with the given username, it throws a UsernameNotFoundException.

		User user = this.userDao.findByUsername(username);
		
		if (user == null) {
			// If no user is found with the given username, throw an exception.
			throw new UsernameNotFoundException("No user found");
		}

		//System.out.println(user);

		return user;
	}
}

