package com.exitAssignment.server.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.exitAssignment.server.model.Product;

@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {
	
	// This interface extends JpaRepository, which provides the basic CRUD operations for the Product entity.
	// It is annotated with @Repository to indicate that it is a repository bean.
	
	// findByProductName(): This method is used to search for products by their name.
	// It takes a String parameter representing the product name and returns a List of products with matching names.
	public List<Product> findByProductName(String productName);
	
	// findByProductId(): This method is used to search for a product by its ID.
	// It takes an int parameter representing the product ID and returns the product with the matching ID.
	public Product findByProductId(int productId);
}
