package com.exitAssignment.server.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exitAssignment.server.dao.ProductReviewsDao;
import com.exitAssignment.server.model.Product;
import com.exitAssignment.server.model.ProductReview;

/***
 * @author Yashaswi Srivastava
 */

@Service
public class ProductReviewService {
	
	@Autowired
	private ProductReviewsDao productReviewsDao;
	
	@Autowired
	private ProductService productService;
	
	public ProductReview addReviews(ProductReview review, int id) {
		// This method is used to add a product review to a specific product.
		// It takes the review object and the product id as parameters.
		// It retrieves the product from the database using the ProductService based on the given id.
		// It adds the review to the product's review list and sets the product for the review.
		// Then, it saves the review using the ProductReviewsDao.
		// Finally, it returns the saved review.

		Product p = productService.getProductById(id);
		p.getReview().add(review);
		review.setProduct(p);
		productReviewsDao.save(review);

		return review;
	}

	/**
	 * get all reviews
	 * 
	 * @return a list of all product reviews
	 */
	public List<ProductReview> getReview() {
		// This method retrieves all the product reviews from the database.
		// It uses the findAll() method of the ProductReviewsDao to get all the reviews.
		// The reviews are returned as a List<ProductReview>.

		List<ProductReview> list = (List<ProductReview>) this.productReviewsDao.findAll();
		//System.out.println(list);

		return list;
	}
	
	public void updateState(String state, int id) {
		// This method updates the state of a product review.
		// It takes the new state and the review id as parameters.
		// It retrieves the review from the database using the getOne() method of the ProductReviewsDao.
		// Then, it updates the state of the review and saves it using the ProductReviewsDao.
		
		ProductReview review = productReviewsDao.getOne(id);
		review.setState(state);
		productReviewsDao.save(review);
	}
	
	public Long getNoOfReviews() {
		// This method returns the total number of product reviews.
		// It uses the count() method of the ProductReviewsDao to get the count.
		// The count is returned as a Long value.
		
		return this.productReviewsDao.count();
	}
}
