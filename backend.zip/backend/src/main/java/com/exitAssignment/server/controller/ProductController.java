package com.exitAssignment.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exitAssignment.server.model.Product;
import com.exitAssignment.server.service.ProductService;

/***
 * @author Yashaswi Srivastava
 */

// Product Controller
@CrossOrigin("*")
@RequestMapping("/api")
@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/all-products")
	public List<Product> getAllProduct() {
		// Retrieve all products from the productService
		return this.productService.getProduct();
	}
	
	@CrossOrigin()
	@PostMapping("/add-products")
	public Product addProduct(@RequestBody Product product) {
		// Add a new product using the productService
		return this.productService.addProduct(product);
	}
	
	@SuppressWarnings("rawtypes")
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/search/{productName}")
	public ResponseEntity getproductByName(@PathVariable String productName) {
		// Search for products by name using the productService
		List<Product> product = this.productService.getProductByName(productName);

		if (product == null) {
			// If no product is found, return a 401 Unauthorized response
			return ResponseEntity.status(401).build();
		}
		
		// If products are found, return a 200 OK response with the product list
		return ResponseEntity.status(200).body(product);
	}
	
	@GetMapping("/product/{id}")
	public Product productById(@PathVariable int id) {
		// Retrieve a product by its ID using the productService
		return this.productService.getProductById(id);
	}
	
	@GetMapping("/count-products")
	public Long getProductCount() {
		// Get the count of products using the productService
		return this.productService.getNumberofProducts();
	}
}
