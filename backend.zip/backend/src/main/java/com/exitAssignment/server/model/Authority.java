package com.exitAssignment.server.model;

import org.springframework.security.core.GrantedAuthority;

public class Authority implements GrantedAuthority {
	
/***
 * @author Yashaswi Srivastava
 */
	private static final long serialVersionUID = 1L;
	private String authority;
	public Authority(String authority)
	{
		//System.out.println(authority);

		this.authority=authority;
	}
	@Override
	public String getAuthority() {
		
		return this.authority;
	}

}
