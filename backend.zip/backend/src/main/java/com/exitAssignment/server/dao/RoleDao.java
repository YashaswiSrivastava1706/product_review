package com.exitAssignment.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.exitAssignment.server.model.Role;

// This interface extends JpaRepository, which provides the basic CRUD operations for the Role entity.

public interface RoleDao extends JpaRepository<Role, Long> {

	// No additional methods are defined in this interface since JpaRepository already provides all the necessary CRUD operations for the Role entity.
	
	// The RoleDao interface acts as a repository for managing Role entities in the database. It allows performing CRUD operations (create, read, update, delete) on Role objects.
	// JpaRepository is a generic interface that takes two parameters: the entity type (Role) and the primary key type (Long).
	// By extending JpaRepository<Role, Long>, the RoleDao interface inherits the methods for CRUD operations from JpaRepository, such as save(), findById(), findAll(), delete(), etc.
}
