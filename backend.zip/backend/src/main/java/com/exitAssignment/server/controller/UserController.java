package com.exitAssignment.server.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exitAssignment.server.model.Role;
import com.exitAssignment.server.model.User;
import com.exitAssignment.server.model.UserRole;
import com.exitAssignment.server.service.UserService;

import at.favre.lib.crypto.bcrypt.BCrypt;

/***
 * @author Yashaswi Srivastava
 */

@CrossOrigin
@RequestMapping("/api")
@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/")
	public String find() {
		// This is a sample endpoint to test the user API
		return "This is user API";
	}
	
	@SuppressWarnings("rawtypes")
	@PostMapping("/register")
	public ResponseEntity register(@RequestBody User user) {
		Set<UserRole> roles = new HashSet<>();
		
		// Create a default role for the user
		Role role = new Role();
		role.setRoleName("USER");
		role.setRoleId(45L);
		
		UserRole userRole = new UserRole();
		userRole.setRole(role);
		userRole.setUser(user);
		roles.add(userRole);
		
		// Hash the user's password using BCrypt
		String bcryptHashString = BCrypt.withDefaults().hashToString(12, user.getPassword().toCharArray());
		user.setPassword(bcryptHashString);
		
		User createUser = userService.addUser(user, roles);
		
		if (createUser == null) {
			// User registration failed
			return ResponseEntity.status(401).build();
		} else {
			// User registration successful
			return ResponseEntity.status(200).build();
		}
	}
	
	@GetMapping("/{username}")
	public User getUserByName(@PathVariable String username) {
		// Retrieve a user by their username
		return this.userService.getUserByUserName(username);
	}
	
	@GetMapping("/user")
	public List<User> getAllUsers() {
		// Retrieve all users
		return this.userService.getAllUser();
	}
	
	@GetMapping("/count-users")
	public Long getUserCount() {
		// Get the count of users
		return this.userService.getCountUser();
	}
}
