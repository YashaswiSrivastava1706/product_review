package com.exitAssignment.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/***
 * @author Yashaswi Srivastava
 */

/**
 * The main class that starts the backend application.
 */
@SpringBootApplication
public class BackendApplication {
    public static void main(String[] args) {
        // The SpringApplication.run() method starts the Spring Boot application.
        // It takes the class of the application (BackendApplication) and the command-line arguments as parameters.
        SpringApplication.run(BackendApplication.class, args);
        System.out.println("Hey there!");
    }

    /*
    public void run(String... args) throws Exception {
        User user = new User();
        user.setFirstName("Yashaswi");
        user.setLastName("Srivastava");
        user.setPassword(this.bCryptPasswordEncoder.encode("1234"));
        user.setUserName("yavi");

        Role role1 = new Role();
        role1.setRoleId(44L);
        role1.setRoleName("ADMIN");

        Set<UserRole> userRoleSet = new HashSet<>();
        UserRole userRole = new UserRole();

        userRole.setRole(role1);
        userRole.setUser(user);
        userRoleSet.add(userRole);

        User user1 = this.userService.addUser(user, userRoleSet);
        System.out.println(user1.getUsername());
    }
    */
}
