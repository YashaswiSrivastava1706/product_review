package com.exitAssignment.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.exitAssignment.server.model.ProductReview;

@Repository
public interface ProductReviewsDao extends JpaRepository<ProductReview, Integer> {
	
	// This interface extends JpaRepository, which provides the basic CRUD operations for the ProductReview entity.
	// It is annotated with @Repository to indicate that it is a repository bean.
	
	// No additional methods are defined in this interface since JpaRepository already provides all the necessary CRUD operations for the ProductReview entity.
}
